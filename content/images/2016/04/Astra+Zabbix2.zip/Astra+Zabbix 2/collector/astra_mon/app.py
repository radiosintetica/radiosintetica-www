from aiohttp import web
import asyncio
from time import time



async def receiveDataFromStreamAstra(request):
  json = await request.json()
  json = json.pop()
  if "channel" in json:
    request.app.cfgch[json["channel"]["id"]] = json
    return web.Response(text = "ok")
  if "channel_id" in json:
    request.app.channels[json["channel_id"]] = json
    return web.Response(text = "ok")
  if "dvb" in json:
    request.app.cfgdvb[json["dvb"]["id"]] = json
    return web.Response(text = "ok")
  if "dvb_id" in json:
    request.app.dvbs[json["dvb_id"]] = json
    return web.Response(text = "ok")
  raise RuntimeError("Ошибка!")


async def getChannelInfo(request):
  channelId = request.match_info['channelId']
  if channelId not in request.app.channels:
    return web.Response(text = "Not found channel with id = {}".format(channelId), status = 404)
  return web.json_response(request.app.channels[channelId])

async def getChannelsInfo(request):
  return web.json_response(request.app.channels)

async def getCfgChannels(request):
  return web.json_response(request.app.cfgch)

async def getDvbInfo(request):
  dvbId = request.match_info['dvbId']
  if dvbId not in request.app.dvbs:
    return web.Response(text = " Not found dvb with id = {}".format(dvbId), status = 404)
  return web.json_response(request.app.dvbs[dvbId])

async def getDvbsInfo(request):
  return web.json_response(request.app.dvbs)

async def getCfgDvbs(request):
  return web.json_response(request.app.cfgdvb)



app = web.Application(loop = asyncio.get_event_loop())
app.router.add_post('/astra/', receiveDataFromStreamAstra)
app.router.add_get('/channel/{channelId}', getChannelInfo)
app.router.add_get('/channels/', getChannelsInfo)
app.router.add_get('/cfg_channels/', getCfgChannels)
app.router.add_get('/dvb/{dvbId}', getDvbInfo)
app.router.add_get('/dvbs/', getDvbsInfo)
app.router.add_get('/cfg_dvbs/', getCfgDvbs)
app.cfgch = {}
app.cfgdvb = {}
app.channels = {}
app.dvbs = {}



# стирает данные если мониторинг не присылает их больше 5 минут
async def removeExpiredData(app):
  try:
    otmetka = time() - 60 * 5
    for channel, data in app.channels.items():
      timestamp = int(data["timestamp"])
      if timestamp < otmetka:
        del(app.channels[channel])
  except Exception as e:
    pass
  finally:
    await asyncio.sleep(5)
    app.loop.create_task(removeExpiredData(app))


app.loop.create_task(removeExpiredData(app))

if __name__ == "__main__":
  web.run_app(app, port = 8080)

